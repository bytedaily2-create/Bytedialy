import { getStore } from "@netlify/blobs";
import type { Config, Context } from "@netlify/functions";

export default async (req: Request, context: Context) => {
  const store = getStore({ name: "user-coins", consistency: "strong" });
  const url = new URL(req.url);

  if (req.method === "GET") {
    const userId = url.searchParams.get("userId");
    if (!userId) {
      return Response.json({ error: "Missing userId" }, { status: 400 });
    }

    const data = await store.get(userId, { type: "json" });
    if (!data) {
      return Response.json({ coins: 0, lastQuizDate: null });
    }
    return Response.json(data);
  }

  if (req.method === "POST") {
    const body = await req.json();
    const { userId, coins, lastQuizDate } = body;

    if (!userId || typeof coins !== "number") {
      return Response.json(
        { error: "Missing userId or coins" },
        { status: 400 }
      );
    }

    const data = { coins, lastQuizDate: lastQuizDate || null };
    await store.setJSON(userId, data);
    return Response.json(data);
  }

  return Response.json({ error: "Method not allowed" }, { status: 405 });
};

export const config: Config = {
  path: "/api/coins",
};
