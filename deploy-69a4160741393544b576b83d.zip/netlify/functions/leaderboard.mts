import { getStore } from "@netlify/blobs";
import type { Config, Context } from "@netlify/functions";

interface LeaderboardEntry {
  username: string;
  coins: number;
  lastQuizDate: string | null;
}

export default async (req: Request, context: Context) => {
  const store = getStore({ name: "leaderboard", consistency: "strong" });
  const url = new URL(req.url);

  if (req.method === "GET") {
    const username = url.searchParams.get("username");

    // If username provided, return that user's score
    if (username) {
      const key = username.toLowerCase().trim();
      const data = await store.get(key, { type: "json" }) as LeaderboardEntry | null;
      if (!data) {
        return Response.json({ found: false });
      }
      return Response.json({ found: true, ...data });
    }

    // Otherwise return full leaderboard
    const { blobs } = await store.list();
    const entries: LeaderboardEntry[] = [];

    for (const blob of blobs) {
      const data = await store.get(blob.key, { type: "json" }) as LeaderboardEntry | null;
      if (data) {
        entries.push(data);
      }
    }

    // Sort by coins descending
    entries.sort((a, b) => b.coins - a.coins);

    return Response.json({ leaderboard: entries });
  }

  if (req.method === "POST") {
    const body = await req.json();
    const { username, coins, lastQuizDate } = body;

    if (!username || typeof coins !== "number") {
      return Response.json(
        { error: "Missing username or coins" },
        { status: 400 }
      );
    }

    const key = username.toLowerCase().trim();

    // Check if username already exists
    const existing = await store.get(key, { type: "json" }) as LeaderboardEntry | null;

    if (existing && existing.coins > coins) {
      // Don't overwrite a higher score
      return Response.json(existing);
    }

    const data: LeaderboardEntry = {
      username: username.trim(),
      coins,
      lastQuizDate: lastQuizDate || null,
    };
    await store.setJSON(key, data);
    return Response.json(data);
  }

  return Response.json({ error: "Method not allowed" }, { status: 405 });
};

export const config: Config = {
  path: "/api/leaderboard",
};
