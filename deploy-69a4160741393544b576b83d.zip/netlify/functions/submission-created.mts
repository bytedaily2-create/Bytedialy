import { getStore } from "@netlify/blobs";
import type { Context } from "@netlify/functions";

interface FormPayload {
  form_name: string;
  data: Record<string, string>;
  created_at: string;
}

export default async (req: Request, context: Context) => {
  const { payload } = (await req.json()) as { payload: FormPayload };

  if (payload.form_name !== "byte-contact") {
    return new Response("OK");
  }

  const store = getStore({ name: "contact-submissions", consistency: "strong" });

  const submission = {
    name: payload.data.name || "",
    email: payload.data.email || "",
    mobile: payload.data.mobile || "",
    submittedAt: payload.created_at,
  };

  const id = `submission-${Date.now()}`;
  await store.setJSON(id, submission);

  console.log("Contact form submission stored:", id, submission);

  return new Response("OK");
};
